!:%s/old/new/g ->replace
!grep 'total energy   ETOTAL' OUTCAR > totalenergy.dat
program main
implicit none
integer                  :: i,Nstep
real(kind=8)             :: b,timestep
character(len=10)        :: tmp
real(kind=8),allocatable ::a(:)  

!These parameters should input by hand
timestep=0.001
Nstep=10000

allocate(a(Nstep))
call system('grep "total energy   ETOTAL" OUTCAR > totalenergy.dat' )
open(unit=10,file='totalenergy.dat')
do i=1,Nstep
   read(10,*)tmp,tmp,tmp,tmp,a(i)
end do
close(10)

open(unit=20,file='Etotal-t.dat')
b=0
do i=1,Nstep
      b=b+timestep
      write(20,*)b,a(i)
end do
close(20)


!grep temperature OUTCAR | grep 'kin. lattice' >temperature.dat
call system('grep temperature OUTCAR | grep "kin. lattice" >temperature.dat' )
open(unit=10,file='temperature.dat')
do i=1,Nstep
   !   read(10,"(64XF8.3)")a(i)
      read(10,*)tmp,tmp,tmp,tmp,tmp,a(i)
end do
close(10)

open(unit=20,file='T-t.dat')
b=0
do i=1,Nstep
      b=b+timestep
      write(20,*)b,a(i)
end do
close(20)

!grep 'volume of cell' OUTCAR > volume.dat  
!the first line is not in the loop, so we delete it
call system('grep "volume of cell" OUTCAR > volume.dat' ) !only for constant V
open(unit=10,file='volume.dat')
do i=1,Nstep
   read(10,*)tmp,tmp,tmp,tmp,a(i)
end do
close(10)

open(unit=20,file='V-t.dat')
b=0
do i=1,Nstep
      b=b+timestep
      write(20,*)b,a(i)
end do
close(20)

call system('grep "% ion-electron   TOTEN" OUTCAR > U.dat' )
open(unit=10,file='U.dat')
do i=1,Nstep
   read(10,*)tmp,tmp,tmp,tmp,a(i)
end do
close(10)

open(unit=20,file='U-t.dat')
b=0
do i=1,Nstep
      b=b+timestep
      write(20,*)b,a(i)
end do
close(20)

!call system('grep "kinetic energy EKIN" OUTCAR > Ek.dat' )
!open(unit=30,file='Ek.dat')
!do i=1,Nstep
!   read(30,*)tmp,tmp,tmp,tmp,a(i)
!end do
!close(30)
!
!open(unit=40,file='Ek-t.dat')
!b=0
!do i=1,Nstep
!      b=b+timestep
!      write(40,*)b,a(i)
!end do
!close(40)
!
!call system('grep "nose potential ES" OUTCAR > nose-U.dat' )
!open(unit=50,file='nose-U.dat')
!do i=1,Nstep
!   read(50,*)tmp,tmp,tmp,tmp,a(i)
!end do
!close(50)
!
!open(unit=60,file='nose-U-t.dat')
!b=0
!do i=1,Nstep
!      b=b+timestep
!      write(60,*)b,a(i)
!end do
!close(60)
!
!call system('grep "nose kinetic   EPS" OUTCAR > nose-Ek.dat' )
!open(unit=70,file='nose-Ek.dat')
!do i=1,Nstep
!   read(70,*)tmp,tmp,tmp,tmp,a(i)
!end do
!close(70)
!
!open(unit=80,file='nose-Ek-t.dat')
!b=0
!do i=1,Nstep
!      b=b+timestep
!      write(80,*)b,a(i)
!end do
!close(80)

deallocate(a)
!call system('rm totalenergy.dat pressure.dat temperature.dat volume.dat U.dat Ek.dat nose-U.dat nose-Ek.dat')
call system('rm totalenergy.dat pressure.dat temperature.dat volume.dat U.dat')
end program
