#!/bin/bash

# 初始化输出文件
output_file="enthalpy.dat"
rm -f "$output_file"

# 遍历1-10的文件夹
for dir in $(seq 300 100 600); do
    if [ -d "$dir" ]; then
        cd "$dir"

        if [ -f "OUTCAR" ]; then
            # 提取焓值
            enthalpy=$(awk '/enthalpy is  TOTEN/{print $5}' OUTCAR | tail -1)

            # 检查优化状态
            if tail -n 50 OUTCAR | grep -q "reached required accuracy"; then
                converged="Yes"
            else
                converged="No"
            fi

            echo "$dir  $enthalpy  $converged" >> "../$output_file"
        else
            # OUTCAR不存在
            echo "$dir  N/A  N/A" >> "../$output_file"
        fi

        cd ..
    else
        # 文件夹不存在
        echo "$dir  N/A  N/A" >> "$output_file"
    fi
done

# 格式化输出文件
column -t "$output_file"
