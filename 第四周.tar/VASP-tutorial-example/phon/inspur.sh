#!/bin/bash 
#SBATCH --job-name=test
#SBATCH --partition=public
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --output=log.out.%j
#SBATCH --error=log.err.%j

source /work/env/intel2018



for i in `ls POSCAR-* | grep -o '[0-9]\{3\}'`
do
mkdir $i
cp POSCAR-$i $i/POSCAR
cp POTCAR $i
cp INCAR $i
cd $i
mpirun -n 48 /work/software/vasp.6.1.0-intel-2018/vasp_std  > log 2>&1
cd ..
cp $i/vasprun.xml vasprun.xml-$i
done
