#!/bin/bash 
#SBATCH --job-name=test
#SBATCH --partition=public
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=48
#SBATCH --output=log.out.%j
#SBATCH --error=log.err.%j

source /work/env/intel2018

mpirun -n 48 /work/software/vasp.6.1.0-intel-2018/vasp_std  > log 2>&1
